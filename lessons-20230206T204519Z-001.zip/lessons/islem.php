<?php 	
echo $_GET['ad'];
echo "<br>";
echo $_GET['soyad'];


echo $_GET['kullanici_id'];


?>